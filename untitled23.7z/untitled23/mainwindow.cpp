#include <QtGui>

#include "mainwindow.h"
#include "dragdropmodel.h"
#include <QMenu>
#include <QMenuBar>
#include <QTreeView>
#include "treemodel.h"
MainWindow::MainWindow()
{
    QMenu *fileMenu = new QMenu(tr("&File"));
    QAction *quitAction = fileMenu->addAction(tr("E&xit"));
    quitAction->setShortcut(tr("Ctrl+Q"));
    menuBar()->addMenu(fileMenu);
//  For convenient quoting:
    this->treeView = new QTreeView(this);
    treeView->setDragEnabled(true);
    treeView->setAcceptDrops(true);
   // this->treeView = treeView;

    connect(quitAction, SIGNAL(triggered()), this, SLOT(close()));

    setupItems();

    setCentralWidget(treeView);
    setWindowTitle(tr("Tree View"));
}

void MainWindow::setupItems()
{
    QStringList items;
    items << tr("New_Message_1\t(0x01)")
          << tr("  New_Signal_1\t")
          << tr("  New_Signal_2\t")
          << tr("New_Message_2\t(0x02)")
          << tr("  New_Signal_3\t")
          << tr("  New_Signal_4\t");
    DragDropModel *model = new DragDropModel(items, this);
    TreeModel *tree = new TreeModel("aa",this);
    qDebug()<<"tree.a" <<tree->a;
    QModelIndex index = model->index(0, 0, QModelIndex());
    model->insertRows(2, 3, index);
    index = model->index(0, 0, QModelIndex());
    index = model->index(2, 0, index);
    model->setData(index, QVariant("New_Signal_5"));
    model->removeRows(3, 2, index.parent());
    treeView->setModel(model);


}
